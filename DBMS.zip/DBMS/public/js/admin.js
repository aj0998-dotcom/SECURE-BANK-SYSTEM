/**
 * Admin Panel Logic
 */
document.addEventListener('DOMContentLoaded', async () => {
  if (!requireAuth()) return;
  const user = getUser();
  if (user.role !== 'admin') { window.location.href = '/dashboard.html'; return; }

  document.getElementById('sidebar-toggle').addEventListener('click', () => document.getElementById('sidebar').classList.toggle('open'));
  document.getElementById('user-name').textContent = 'Administrator';
  document.getElementById('user-email').textContent = user.email;

  // Tab switching
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
    });
  });

  // Load stats
  try {
    const stats = await apiRequest('/admin/stats');
    document.getElementById('admin-stats').innerHTML = `
      <div class="stat-card blue fade-in"><div class="stat-icon">👥</div><div class="stat-value">${stats.totalCustomers}</div><div class="stat-label">Total Customers</div></div>
      <div class="stat-card green fade-in" style="animation-delay:.1s"><div class="stat-icon">💳</div><div class="stat-value">${stats.activeAccounts}</div><div class="stat-label">Active Accounts</div></div>
      <div class="stat-card purple fade-in" style="animation-delay:.2s"><div class="stat-icon">💰</div><div class="stat-value">${formatCurrency(stats.totalBalance)}</div><div class="stat-label">Total Balance</div></div>
      <div class="stat-card amber fade-in" style="animation-delay:.3s"><div class="stat-icon">📋</div><div class="stat-value">${stats.totalTransactions}</div><div class="stat-label">Total Transactions</div></div>
    `;
  } catch (err) { showToast('Failed to load stats', 'error'); }

  // Load customers
  try {
    const data = await apiRequest('/admin/customers');
    document.getElementById('cust-tbody').innerHTML = data.customers.map(c => `<tr>
      <td>${c.customer_id}</td>
      <td><strong>${c.first_name} ${c.last_name}</strong></td>
      <td>${c.email}</td><td>${c.phone}</td>
      <td>${c.customer_type}</td><td>${c.account_count}</td>
      <td style="font-weight:600;">${formatCurrency(c.total_balance)}</td>
      <td>${getStatusBadge(c.status)}</td>
    </tr>`).join('');
  } catch (err) { document.getElementById('cust-tbody').innerHTML = '<tr><td colspan="8" class="text-muted">Failed to load</td></tr>'; }

  // Load accounts
  try {
    const data = await apiRequest('/admin/accounts');
    document.getElementById('acc-tbody').innerHTML = data.accounts.map(a => `<tr>
      <td>${a.account_id}</td>
      <td style="font-family:monospace;font-size:0.8rem;">${a.account_number}</td>
      <td>${a.customer_name}</td><td>${a.account_type}</td>
      <td style="font-weight:600;">${formatCurrency(a.balance)}</td>
      <td>${a.branch_code}</td><td>${formatDate(a.opening_date)}</td>
      <td>${getStatusBadge(a.status)}</td>
    </tr>`).join('');
  } catch (err) { document.getElementById('acc-tbody').innerHTML = '<tr><td colspan="8" class="text-muted">Failed to load</td></tr>'; }

  // Load transactions
  try {
    const data = await apiRequest('/admin/transactions');
    document.getElementById('txn-tbody').innerHTML = data.transactions.map(t => `<tr>
      <td>${t.transaction_id}</td>
      <td>${t.customer_name}</td>
      <td style="font-family:monospace;font-size:0.8rem;">${t.account_number}</td>
      <td>${getTransactionBadge(t.transaction_type)}</td>
      <td style="font-weight:600;">${formatCurrency(t.amount)}</td>
      <td>${formatCurrency(t.balance_after)}</td>
      <td>${formatDateTime(t.transaction_date)}</td>
      <td>${getStatusBadge(t.status)}</td>
    </tr>`).join('');
  } catch (err) { document.getElementById('txn-tbody').innerHTML = '<tr><td colspan="8" class="text-muted">Failed to load</td></tr>'; }
});
