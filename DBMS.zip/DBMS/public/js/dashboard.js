/**
 * Dashboard Page Logic
 */
document.addEventListener('DOMContentLoaded', async () => {
  if (!requireAuth()) return;
  const user = getUser();
  if (user.role === 'admin') { window.location.href = '/admin.html'; return; }

  // Sidebar toggle
  document.getElementById('sidebar-toggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
  });

  // Set user info
  const name = user.customer ? `${user.customer.first_name} ${user.customer.last_name}` : user.email;
  document.getElementById('user-avatar').textContent = name.charAt(0).toUpperCase();
  document.getElementById('user-name').textContent = name;
  document.getElementById('user-email').textContent = user.email;
  document.getElementById('welcome-msg').textContent = `Welcome, ${user.customer ? user.customer.first_name : 'User'}!`;
  document.getElementById('date-display').textContent = new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  try {
    const data = await apiRequest(`/dashboard/${user.customerId}`);
    renderStats(data.summary);
    renderTransactions(data.recentTransactions);
    renderAccountsPreview(data.accounts);
  } catch (err) {
    showToast(err.error || 'Failed to load dashboard', 'error');
  }
});

function renderStats(s) {
  document.getElementById('stats-grid').innerHTML = `
    <div class="stat-card blue fade-in"><div class="stat-icon">💰</div><div class="stat-value">${formatCurrency(s.totalBalance)}</div><div class="stat-label">Total Balance</div></div>
    <div class="stat-card green fade-in" style="animation-delay:0.1s"><div class="stat-icon">💳</div><div class="stat-value">${s.activeAccounts}</div><div class="stat-label">Active Accounts</div></div>
    <div class="stat-card purple fade-in" style="animation-delay:0.2s"><div class="stat-icon">📑</div><div class="stat-value">${s.totalLoans}</div><div class="stat-label">Active Loans</div></div>
    <div class="stat-card amber fade-in" style="animation-delay:0.3s"><div class="stat-icon">⏳</div><div class="stat-value">${formatCurrency(s.totalOutstanding)}</div><div class="stat-label">Loan Outstanding</div></div>
  `;
}

function renderTransactions(txns) {
  const tbody = document.getElementById('txn-tbody');
  if (!txns || txns.length === 0) { tbody.innerHTML = '<tr><td colspan="6" class="text-muted" style="text-align:center;padding:2rem;">No recent transactions</td></tr>'; return; }
  tbody.innerHTML = txns.map(t => `<tr class="fade-in">
    <td>${formatDateTime(t.transaction_date)}</td>
    <td style="font-family:monospace;font-size:0.8rem;">${t.account_number || '—'}</td>
    <td>${getTransactionBadge(t.transaction_type)}</td>
    <td class="${t.transaction_type === 'Deposit' || t.transaction_type === 'Interest Credit' ? 'text-green' : 'text-red'}" style="font-weight:600;">${t.transaction_type === 'Deposit' || t.transaction_type === 'Interest Credit' ? '+' : '-'}${formatCurrency(t.amount)}</td>
    <td>${formatCurrency(t.balance_after)}</td>
    <td>${getStatusBadge(t.status)}</td>
  </tr>`).join('');
}

function renderAccountsPreview(accounts) {
  const container = document.getElementById('accounts-preview');
  if (!accounts || accounts.length === 0) { container.innerHTML = '<div class="empty-state"><div class="empty-icon">💳</div><h3>No accounts yet</h3><p>Create your first account to get started.</p></div>'; return; }
  container.innerHTML = accounts.slice(0, 3).map(a => {
    const typeClass = a.account_type === 'Savings' ? 'savings' : a.account_type === 'Current' ? 'current' : 'fd';
    const colors = { Savings: 'var(--accent-green)', Current: 'var(--accent-purple)', 'Fixed Deposit': 'var(--accent-amber)' };
    return `<div class="account-card ${typeClass} fade-in">
      <span class="account-type-badge" style="background:${colors[a.account_type]}22;color:${colors[a.account_type]}">${a.account_type}</span>
      ${getStatusBadge(a.status)}
      <div class="account-number">•••• •••• •••• ${a.account_number.slice(-4)}</div>
      <div class="account-balance"><span class="currency">₹</span>${parseFloat(a.balance).toLocaleString('en-IN')}</div>
      <div class="mt-1 text-muted" style="font-size:0.8rem;">Branch: ${a.branch_code} | Rate: ${a.interest_rate}%</div>
    </div>`;
  }).join('');
}
