/**
 * Accounts Page Logic
 */
document.addEventListener('DOMContentLoaded', async () => {
  if (!requireAuth()) return;
  const user = getUser();
  if (user.role === 'admin') { window.location.href = '/admin.html'; return; }

  document.getElementById('sidebar-toggle').addEventListener('click', () => document.getElementById('sidebar').classList.toggle('open'));
  const name = user.customer ? `${user.customer.first_name} ${user.customer.last_name}` : user.email;
  document.getElementById('user-avatar').textContent = name.charAt(0).toUpperCase();
  document.getElementById('user-name').textContent = name;
  document.getElementById('user-email').textContent = user.email;

  const modal = document.getElementById('modal-overlay');
  document.getElementById('btn-new-account').addEventListener('click', () => modal.classList.remove('hidden'));
  document.getElementById('modal-cancel').addEventListener('click', () => modal.classList.add('hidden'));
  modal.addEventListener('click', e => { if (e.target === modal) modal.classList.add('hidden'); });

  await loadAccounts();

  document.getElementById('create-account-form').addEventListener('submit', async e => {
    e.preventDefault();
    const alertBox = document.getElementById('modal-alert');
    try {
      await apiRequest('/accounts', {
        method: 'POST',
        body: JSON.stringify({
          customer_id: user.customerId,
          account_type: document.getElementById('acc-type').value,
          branch_code: document.getElementById('acc-branch').value,
          initial_deposit: document.getElementById('acc-deposit').value
        })
      });
      showToast('Account created successfully!', 'success');
      modal.classList.add('hidden');
      await loadAccounts();
    } catch (err) {
      alertBox.innerHTML = `<div class="alert alert-error">❌ ${err.error || 'Failed to create account'}</div>`;
    }
  });
});

async function loadAccounts() {
  const user = getUser();
  const container = document.getElementById('accounts-container');
  try {
    const data = await apiRequest(`/accounts/${user.customerId}`);
    if (!data.accounts || data.accounts.length === 0) {
      container.innerHTML = '<div class="empty-state"><div class="empty-icon">💳</div><h3>No accounts</h3><p>Click "New Account" to create one.</p></div>';
      return;
    }
    container.innerHTML = data.accounts.map(a => {
      const tc = a.account_type === 'Savings' ? 'savings' : a.account_type === 'Current' ? 'current' : 'fd';
      const colors = { Savings: 'var(--accent-green)', Current: 'var(--accent-purple)', 'Fixed Deposit': 'var(--accent-amber)' };
      return `<div class="account-card ${tc} fade-in">
        <div class="flex-between mb-1">
          <span class="account-type-badge" style="background:${colors[a.account_type]}22;color:${colors[a.account_type]}">${a.account_type}</span>
          ${getStatusBadge(a.status)}
        </div>
        <div class="account-number">•••• •••• •••• ${a.account_number.slice(-4)}</div>
        <div class="account-balance"><span class="currency">₹</span>${parseFloat(a.balance).toLocaleString('en-IN')}</div>
        <div class="mt-1 text-muted" style="font-size:0.8rem;">Branch: ${a.branch_code} | Interest: ${a.interest_rate}% | Opened: ${formatDate(a.opening_date)}</div>
        <div class="mt-2 flex gap-1">
          <a href="/transactions.html?account=${a.account_id}" class="btn btn-outline btn-sm">View Transactions</a>
          ${a.status === 'Active' ? `<button class="btn btn-danger btn-sm" onclick="closeAccount(${a.account_id})">Close</button>` : ''}
        </div>
      </div>`;
    }).join('');
  } catch (err) {
    container.innerHTML = `<div class="alert alert-error">❌ ${err.error || 'Failed to load accounts'}</div>`;
  }
}

async function closeAccount(accountId) {
  if (!confirm('Are you sure you want to close this account? This action cannot be undone.')) return;
  try {
    await apiRequest(`/accounts/${accountId}`, { method: 'DELETE' });
    showToast('Account closed successfully.', 'success');
    await loadAccounts();
  } catch (err) {
    showToast(err.error || 'Failed to close account', 'error');
  }
}
